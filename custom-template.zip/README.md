# ig-template-fhir

package hl7.fhir.template

Template used for most HL7-defined FHIR implementation guides (based on ig-template-base - package = hl7.base.template).  Adds HL7 logos.
